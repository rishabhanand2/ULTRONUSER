# PLUGIN MADE BY @H1M4N5HU0P FOR MAFIABOT
# KEEP CREDITS ELSE GAY

import random, re
from mafiabot.utils import admin_cmd
import asyncio
from telethon import events

@borg.on(admin_cmd(pattern="iloveyou ?(.*)"))
async def _(event):
     if not event.text[0].isalpha() and event.text[0] not in ("/", "#", "@", "!"):
        await event.edit("""😘😘😘😘😘😘😘😘
😘😘😘😘😘😘😘😘
             😘😘😘
             😘😘😘
             😘😘😘
             😘😘😘
             😘😘😘
             😘😘😘
             😘😘😘
             😘😘😘 
             😘😘😘
😘😘😘😘😘😘😘😘
😘😘😘😘😘😘😘😘\n


😘😘
😘😘
😘😘
😘😘
😘😘
😘😘
😘😘
😘😘
😘😘😘😘😘😘😘😘
😘😘😘😘😘😘😘😘\n
⁭
           😘😘😘😘😘
      😘😘😘😘😘😘😘
   😘😘                       😘😘
 😘😘                          😘😘
😘😘                            😘😘
😘😘                            😘😘
 😘😘                           😘😘
   😘😘                       😘😘
       😘😘😘😘😘😘😘
            😘😘😘😘😘\n
⁭
😘😘                              😘😘
  😘😘                          😘😘
    😘😘                      😘😘
      😘😘                  😘😘
         😘😘             😘😘
           😘😘         😘😘
             😘😘     😘😘
               😘😘 😘😘
                  😘😘😘
                       😘\n
⁭
😘😘😘😘😘😘😘😘
😘😘😘😘😘😘😘😘
😘😘
😘😘
😘😘😘😘😘😘
😘😘😘😘😘😘
😘😘
😘😘
😘😘😘😘😘😘😘😘
😘😘😘😘😘😘😘😘\n

😘😘                         😘😘
  😘😘                    😘😘
     😘😘              😘😘
        😘😘        😘😘
           😘😘  😘😘
              😘😘😘
                😘😘
                😘😘
                😘😘
                😘😘
                😘😘\n
⁭
        😘😘😘😘😘😘
     😘😘😘😘😘😘😘
   😘😘                     😘😘
 😘😘                         😘😘
😘😘                           😘😘
😘😘                           😘😘
 😘😘                         😘😘
   😘😘                     😘😘
      😘😘😘😘😘😘😘
            😘😘😘😘😘\n
⁭
😘😘                      😘😘
😘😘                      😘😘
😘😘                      😘😘
😘😘                      😘😘
😘😘                      😘😘
😘😘                      😘😘
😘😘                      😘😘
  😘😘                  😘😘
      😘😘😘😘😘😘
            😘😘😘😘""")
      
