<h3 align="center">𝚃𝙷𝙴 𝙲𝙻𝙾𝙽𝙴 𝙾𝙵</h3>
<h2 align="center"> <a href="https://github.com/mrnitric/SankiAutobot">🔥 •|| HELLBOT ||• 🔥</a></h2>


<h1 align="center">⚡ 𝐒𝐀𝐍𝐊𝐈 𝐀𝐔𝐓𝐎𝐁𝐎𝐓 ⚡</h1>


[![SANKI LOGO](https://telegra.ph/file/a1720a18da7abfb6d4b66.jpg)](https://t.me/SankiAutobot)


<h2 align="center">The owner would not be responsible for any kind of bans due to the bot.</h2>


# FORK AT YOUR OWN RISK

<details>

  <summary> • INSTALLING • </summary>

### The Easy Way

<h4>⚜️ DEPLOY TO HEROKU ⚜️</h4>

<a href="https://dashboard.heroku.com/new?button-url=https%3A%2F%2Fgithub.com%2Fmrnitric%2FSankiAutobot&template=https%3A%2F%2Fgithub.com%2Fmrnitric%2FSankiAutobot" rel="nofollow" style="background-color: initial; box-sizing: border-box; color: #0366d6; text-decoration-line: none;"><img alt="Deploy" data-canonical-src="https://www.herokucdn.com/deploy/button.svg" src="https://camo.githubusercontent.com/83b0e95b38892b49184e07ad572c94c8038323fb/68747470733a2f2f7777772e6865726f6b7563646e2e636f6d2f6465706c6f792f627574746f6e2e737667" style="border-style: none; box-sizing: initial; max-width: 100%;" /></a></div>

<h2 align="center"> <a href="https://github.com/mrnitric/SankiAutobot">⚡ 𝐒𝐀𝐍𝐊𝐈 𝐀𝐔𝐓𝐎𝐁𝐎𝐓 ⚡</a></h2>

</details>

<details>
  <summary> <h4>Credits 🏅</h4> </summary>

• [JaaduBot](https://github.com/Amberyt/JaaduBot)

• [Uniborg](https://github.com/spechide/uniborg)

• [Hêllẞø†](https://github.com/thevaders/vader)

• [Kittu](https://t.me/A_viyu)

</details>
<details>
  <summary> <h4>Official Supports ✅</h4> </summary>

```
Get help regarding setting up 
your SankiAutobot in our official 
support Group and get updates
notifications in Update Channel.
```

<a href="https://t.me/SankiAutobot"><img src="https://img.shields.io/badge/Join-Support%20Channel-red.svg?style=for-the-badge&logo=Telegram"></a>

</details>

<h1 align="center">⚙️ Set-Up ⚙️</h1>

<details>
  <summary> <h2>Generate String Session</h2> </summary>

- Termux
    - Clone `git clone https://github.com/mrnitric/SankiAutobot.git`
    - Then Do  `cd SankiAutobot`
    - Run String Generator By
           `bash string.sh`
    - Then Fill The Required Details.
    - API ID, API HASH, PHONE NUMBER (WITH COUNTRY CODE)
 
- Repl Run
    - Click [Here](https://replit.com/@nikhilcroaker/music-robo#main.py) to open Repl run.
    - Click On Green Play Button.
    - Wait for a while then fill the details.
    - String will be saved in your Saved Message.
</details>

<details>
  <summary> <h3>HOSTING 😉</h3> </summary>

- Choose A Hosting Site. And fill the mandatory vars.

## Deploys

- You Can Deploy it on 
    - [Zeet](https://zeet.co/new)
    - [Uffizzi](https://uffizzi.com)
    - Any Other VPS.
    - No support for Termux Yet.

## Mandatory Vars

- Some of the environment variables are mandatory.
- These are listed below.
    - `APP_ID`:   You can get this value from [here](https://my.telegram.org)
    - `API_HASH`:   You can get this value from [here](https://my.telegram.org)
    - `ENV`:   `ANYTHING`
    - `STRING_SESSION`:   You can get this value from running `python3 string_session.py` in termux after cloning this repo. Or just using [repl run](https://replit.com/@nikhilcroaker/music-robo#main.py)
    - `LOG_GROUP`:   Make a Channel Or Group and get it's id.
    - `DATABASE_URL`:   Make a database on elephant sql and paste the url.
    - `DB_URI`:   Same as `DATABASE_URL`
    - `BOT_TOKEN`:   Make a Bot from [Botfather](https://t.me/botfather) and paste the bot token here.
    - `BOT_USERNAME`:   Paste the Username of bot that you made from [BotFather](https://t.me/botfather).
- The userbot will not work without setting the mandatory vars.

</details>

<details>
  <summary> <h4>• LICENSE •</h4> </summary>

![](https://www.gnu.org/graphics/gplv3-or-later.png)

Copyright (C) 2021 @MR_NITRIC™

Poject [Sanki Autobot](https://github.com/H1M4N5HU0P/MAFIA-BOT) is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <https://www.gnu.org/licenses/>.

</details>
